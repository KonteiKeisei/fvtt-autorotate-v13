# Changelog

All notable changes to this project will be documented in this file.

## [1.4.4] - 2025-11-02

### Added
- Core setting conflict detection: Module now warns users if Foundry's built-in automatic token rotation is enabled, which conflicts with this module's functionality
- Persistent warning notification displays on world load when core auto-rotate is detected

## [1.4.3] - 2025-11-02

### Fixed
- Token configuration settings now correctly appear in the **Appearance** tab instead of Vision tab
- Changed injection target from `sight.visionMode` to `lockRotation` field

## [1.4.2] - 2025-11-02

### Fixed
- Updated token config injection to use Foundry V13's ApplicationV2 pattern
- Changed from template-based rendering to direct jQuery HTML construction
- Added proper form integration with `app.setPosition({height: "auto"})` to adjust window size

## [1.4.1] - 2025-11-02

### Fixed
- Fixed `Cannot read properties of undefined (reading 'flags')` error
- Updated to access token document via `app.document` instead of `data.object` (V13 ApplicationV2 change)

## [1.4.0] - 2025-11-02

### Changed
- **BREAKING**: Updated compatibility to Foundry VTT V13
- Minimum version changed from V10 to V13
- Verified compatibility updated from V12 to V13

### Fixed
- Updated token configuration injection for ApplicationV2 architecture
- Implemented multiple selector fallbacks for V13 DOM structure
- Maintained backward compatibility with core rotation functionality

## [1.3.18] - Previous Release

### Features (Existing)
- Automatic token rotation based on movement direction
- Token rotation when targeting other tokens
- Configurable rotation offset per token
- Global default rotation mode setting
- Per-token enable/disable controls
- Support for Shift + Arrow keys to rotate without moving
- Rideable module compatibility

---

## Migration Notes: V11/V12 → V13

### What Changed
1. **ApplicationV2 Architecture**: TokenConfig now uses Foundry's new ApplicationV2 system
2. **Data Access**: Token document accessed via `app.document` instead of `data.object`
3. **Form Injection**: Switched to direct jQuery DOM manipulation matching V13 patterns
4. **Tab Structure**: Updated selectors to work with V13's form structure

### Compatibility
- **V13+**: Use version 1.4.0 or later
- **V10-V12**: Use version 1.3.18 or earlier

### Known Issues
- None currently reported

---

## Fork Information

This V13-compatible fork is maintained at: https://github.com/KonteiKeisei/fvtt-autorotate-v13

Original module by Varriount: https://github.com/Varriount/fvtt-autorotate
